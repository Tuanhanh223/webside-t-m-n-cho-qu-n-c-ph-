export const products = [
{id:1,name:'Cà phê sữa đá',category:'Cà phê',price:35000,description:'Cà phê phin đậm vị, sữa đặc béo ngọt.',tag:'Bán chạy'},
{id:2,name:'Bạc xỉu',category:'Cà phê',price:39000,description:'Nhiều sữa, chút cà phê. Dịu dàng cho ngày mới.',tag:'Mộc yêu thích'},
{id:3,name:'Cold brew nguyên bản',category:'Cà phê',price:45000,description:'Ủ lạnh 16 giờ, hậu vị thanh và ít đắng.',tag:''},
{id:4,name:'Latte',category:'Cà phê',price:49000,description:'Espresso quyện sữa tươi, mượt mà từng ngụm.',tag:''},
{id:5,name:'Trà đào cam sả',category:'Trà trái cây',price:45000,description:'Đào mọng, cam tươi và hương sả thơm nhẹ.',tag:'Bán chạy'},
{id:6,name:'Trà vải hoa nhài',category:'Trà trái cây',price:45000,description:'Trà nhài thanh mát cùng vải ngọt thơm.',tag:''},
{id:7,name:'Matcha latte',category:'Matcha',price:55000,description:'Matcha thơm vị trà, cân bằng cùng sữa tươi.',tag:'Thử hôm nay'},
{id:8,name:'Croissant bơ',category:'Bánh ngọt',price:29000,description:'Vỏ bánh giòn nhẹ, ruột mềm thơm bơ.',tag:''}
];
export const branches=['Mộc Nguyễn Huệ · Quận 1','Mộc Võ Văn Tần · Quận 3','Mộc Phan Xích Long · Phú Nhuận'];
export type CartItem={id:number;size:string;topping:string;quantity:number};
export const unitPrice=(item:CartItem)=>{const p=products.find(p=>p.id===item.id); if(!p)throw new Error('Món không tồn tại');return p.price+(item.size==='L'?10000:0)+(item.topping==='Không thêm'?0:7000)};
